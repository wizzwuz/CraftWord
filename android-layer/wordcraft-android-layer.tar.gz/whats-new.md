# Android changes, by upstream version

Each section is shown only in the release of that version (the heading must match the upstream version exactly).
When the next upstream version is released, add a new "## <version>" heading above this one and write its
new Android changes under it. Entries under an old heading never appear again.

## 0.13.2
- **Documents look closer to Word.** WordCraft only looked for fonts in desktop folders, which Android doesn't have, so it used just its few built-in fonts. It now also reads the fonts Android ships (`/system/fonts` and its siblings). That brings Noto and Roboto, and the fonts for Chinese, Japanese, Korean, Arabic, Hindi and other scripts, so text that showed as empty boxes or in the wrong font should now draw.
- The keyboard re-show only on taps, long pastes with line breaks, picture paste, Share debug log, remembered theme and settings, AutoSave, swipe scrolling, update check: as in the last release.
- **Mouse wheel, Ctrl/Shift shortcuts and mouse selection work again.** The Android mouse and keyboard input patch is now applied to upstream's own winit, instead of being skipped.
- **Missing fonts:** documents using fonts this device lacks now use Carlito, Caladea and Liberation (same widths as Calibri, Cambria, Arial and Times New Roman), and Home › Font › Replace Missing Font… lets you pick a replacement for each.
- **Page borders** keep their own distance on each side and honour "measure from text".
- **Welcome screen.** The first time you open the app it explains what WordCraft does and why it needs file access, with a picture, instead of throwing Android's settings page at you. Allow it with one button, or choose "Not now".
- **Documents survive uninstalling.** With file access allowed, documents are kept in Documents/WordCraft, outside the app. Documents kept inside the app by earlier versions move there automatically once access is allowed.
- **Findable file names.** A new document's file is named after its first words plus the date and time ("Meeting notes - 2026-10-31 05-30"), and renamed as those words settle.
- **Light and dark follow the system.** "Use system setting" now really follows Android's theme, live.
- **Ctrl+V on a hardware keyboard pastes** what is on Android's clipboard (Ctrl+Shift+V keeps text only, Ctrl+Alt+V opens Paste Special).
- **Recent documents come back after reinstalling.** The list is also kept in Documents/WordCraft/recent-documents.txt, and restored from it when the app starts with file access allowed.
- **Debug log** shares the newest lines, and saves the whole log to Documents/WordCraft/WordCraft-debug-log.txt.
- **Ctrl+V actually works now.** The previous fix did nothing: egui's own Android clipboard handling silently swallows Ctrl+V before any event reaches the app at all, if nothing had been copied inside the app yet. Ctrl+C, Ctrl+X and Ctrl+V are now handled directly against Android's real clipboard instead.
- **Opening a document from a file manager ("Open with WordCraft") now actually shows it.** It was loading correctly all along, visible only in Recent Documents until tapped again, because nothing closed the Home screen that the app starts on.
- **Stylus support.** A pen or stylus now works like a mouse pointer: its tip moves the cursor and its barrel button clicks, so you can tap and select with a stylus instead of only your finger.
